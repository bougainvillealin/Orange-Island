package com.orangeisland.app.ui.theme

import androidx.compose.runtime.compositionLocalOf

/** User-adjustable look of the assistant's message bubble. */
data class AssistantBubbleStyle(
    val cornerRadius: Float = 20f,
    val glass: Boolean = false,
)

val LocalAssistantBubbleStyle = compositionLocalOf { AssistantBubbleStyle() }
