package com.orangeisland.app.ui.chat.message

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.input.rememberTextFieldState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import com.orangeisland.app.R
import com.orangeisland.app.util.noOpBringIntoView
import com.orangeisland.app.util.splitIntoBubbleSegments
import com.orangeisland.app.model.ChatMessage
import com.orangeisland.app.model.MessageStatus
import com.orangeisland.app.model.Participant
import com.orangeisland.app.model.ToolCallDisplayModes
import com.orangeisland.app.ui.common.DecorativeCorner
import com.orangeisland.app.ui.common.LocalOrangeIslandHaptics
import com.orangeisland.app.ui.theme.ChatType
import com.orangeisland.app.ui.theme.LocalAssistantBubbleStyle
import com.orangeisland.app.ui.components.ColorMath
import org.intellij.markdown.flavours.MarkdownFlavourDescriptor
import kotlinx.coroutines.launch

private const val STREAMING_MARKDOWN_FLUSH_MS = 250L

/**
 * The left-aligned assistant (and error) message content: the streaming status header,
 * the thinking / tool-call timeline or compact segment block, the debounced markdown
 * body, any generated images, the stopped indicator, and the regenerate/overflow
 * action row.
 *
 * Extracted from [MessageItem]. The parent owns the reported-height bookkeeping and the
 * segment-detail sheet, so this composable reports the thought block height through
 * [setThoughtBlockHeight] and surfaces clicked segments through [onSegmentSelected].
 */
@Composable
internal fun AssistantMessageContent(
    message: ChatMessage,
    customAssistantBubbleColor: Long? = null,
    customReasoningPanelColor: Long? = null,
    reasoningPanelAlpha: Float = 1f,
    reasoningBackgroundImagePath: String = "",
    messageBubbleAlpha: Float = 1f,
    contextAlpha: Modifier,
    isStreaming: Boolean,
    isLoading: Boolean,
    isEditingAllowed: Boolean,
    isEditing: Boolean = false,
    onStartEdit: () -> Unit = {},
    onCancelEdit: () -> Unit = {},
    onEditAssistantMessage: (String, String) -> Unit = { _, _ -> },
    showUsageStats: Boolean = false,
    splitBubbleByLine: Boolean = false,
    toolCallDisplayMode: String,
    thoughtExpandedStates: SnapshotStateMap<String, Boolean>,
    isThoughtExpanded: Boolean,
    renderContext: ChatMarkdownRenderContext,
    markdownFlavour: MarkdownFlavourDescriptor,
    branchIndex: Int,
    totalBranches: Int,
    onSwitchBranch: (Int) -> Unit,
    onRegenerate: (String) -> Unit,
    onMediaClick: (List<String>, Int) -> Unit,
    onShowInfo: () -> Unit,
    onShowDelete: () -> Unit,
    onSegmentSelected: (List<Int>) -> Unit,
    setThoughtBlockHeight: (Int) -> Unit,
) {
    @Suppress("DEPRECATION")
    val clipboardManager = LocalClipboardManager.current
    val haptics = LocalOrangeIslandHaptics.current
    var showMenu by remember { mutableStateOf(false) }

    // Outer single-bubble shell wraps the whole message (status header + reasoning panel + body)
    // unless line-split bubbles are active on a finished reply — then the shell must yield so each
    // body segment owns its own bubble silhouette with gaps between them. Streaming keeps the shell:
    // the last line is still being written, so splitting now would make the segment count thrash.
    val bubbleStyle = LocalAssistantBubbleStyle.current
    val useSingleOuterBubble = (customAssistantBubbleColor != null || bubbleStyle.glass) && !(splitBubbleByLine && !isStreaming)

    // During generation, eat horizontal nested-scroll so code blocks
    // cannot be panned. Vertical scroll and taps (thinking header,
    // stop button) pass through normally. Text selection is already
    // prevented during streaming — SelectionContainer is only in the
    // else (!isStreaming) branch.
    val horizontalScrollEater = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset =
                Offset(available.x, 0f)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp)
            .then(contextAlpha)
            .then(if (isStreaming) Modifier.nestedScroll(horizontalScrollEater) else Modifier)
            .then(
                if (useSingleOuterBubble) {
                    val baseColor = customAssistantBubbleColor?.let { ColorMath.argbToColor(it) }
                        ?: MaterialTheme.colorScheme.surfaceContainerHigh
                    val bubbleRadius = bubbleStyle.cornerRadius.dp
                    val bubbleTail = minOf(4f, bubbleStyle.cornerRadius).dp
                    val bubbleShape = RoundedCornerShape(topStart = bubbleRadius, topEnd = bubbleRadius, bottomStart = bubbleTail, bottomEnd = bubbleRadius)
                    val glassFactor = if (bubbleStyle.glass) 0.72f else 1f
                    Modifier
                        .clip(bubbleShape)
                        .background(baseColor.copy(alpha = baseColor.alpha * messageBubbleAlpha * glassFactor))
                        .then(
                            if (bubbleStyle.glass) {
                                Modifier
                                    .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.04f))))
                                    .border(1.dp, Color.White.copy(alpha = 0.55f), bubbleShape)
                            } else Modifier
                        )
                } else Modifier
            )
    ) {
        Column(modifier = if (useSingleOuterBubble) Modifier.padding(12.dp) else Modifier) {
            if (isEditing) {
                AssistantEditModeContent(
                    initialText = message.text,
                    onSave = { newText -> onEditAssistantMessage(message.id, newText); onCancelEdit() },
                    onCancel = onCancelEdit,
                )
                return@Column
            }
            // Status Header
            if (message.participant == Participant.MODEL) {
                val thinkingStatus = stringResource(R.string.thinking_ellipsis)
                val answeringStatus = stringResource(R.string.answering_ellipsis)
                // Hold the last non-fallback label so transitions between
                // "Thinking… → Answering…" don't flash "Sending…" while
                // the first answer token is still in-flight.
                var heldLabel by remember { mutableStateOf("") }
                var heldStatusText by remember { mutableStateOf("") }
                // Update heldLabel after composition to avoid double-recomposition flash
                val thinkingNow = message.status == MessageStatus.THINKING
                val isToolCalling = message.status == MessageStatus.TOOL_CALLING
                val isTranscribing = message.status == MessageStatus.TRANSCRIBING
                val hasActiveAnswer = message.hasActiveAnswerSegment()
                LaunchedEffect(thinkingNow, hasActiveAnswer, message.status) {
                    heldLabel = when {
                        thinkingNow -> "thinking"
                        isToolCalling -> "calling"
                        isTranscribing -> "transcribing"
                        hasActiveAnswer -> "answering"
                        message.status == MessageStatus.SUCCESS || message.status == MessageStatus.ERROR || message.status == MessageStatus.STOPPED -> ""
                        message.status == MessageStatus.SENDING -> ""
                        else -> heldLabel
                    }
                }
                val toolCallingStatus = stringResource(R.string.tool_calling_ellipsis)
                // Video narration reuses MessageStatus.TRANSCRIBING but sets thoughtTitle="Video Narration";
                // pick the matching label so the status bar doesn't say "Transcribing images" for a video.
                val transcribingStatus = if (message.thoughtTitle.equals("Video Narration", ignoreCase = true)) {
                    stringResource(R.string.video_transcription_ellipsis)
                } else {
                    stringResource(R.string.transcription_ellipsis)
                }
                val statusText = when {
                    message.status == MessageStatus.SUCCESS -> if (!showUsageStats && message.tokenCount > 0) stringResource(R.string.cost_tokens, message.tokenCount) else null
                    isStreaming && isTranscribing -> transcribingStatus
                    isStreaming && isToolCalling -> toolCallingStatus
                    isStreaming && thinkingNow -> thinkingStatus
                    isStreaming && hasActiveAnswer -> answeringStatus
                    isStreaming -> when (heldLabel) {
                        "thinking" -> thinkingStatus
                        "calling" -> toolCallingStatus
                        "transcribing" -> transcribingStatus
                        "answering" -> answeringStatus
                        else -> stringResource(R.string.sending_ellipsis)
                    }
                    else -> null
                }.let { base ->
                    if (base != null && message.retryText != null) "$base (${message.retryText})"
                    else base
                }
                // Hold the last non-null label so the status bar doesn't collapse
                // during the timing gap between isStreaming→false and the DB
                // emitting the updated message status.
                val displayText = when {
                    statusText != null -> statusText.also { heldStatusText = it }
                    message.status == MessageStatus.SENDING || message.status == MessageStatus.THINKING || message.status == MessageStatus.TOOL_CALLING || message.status == MessageStatus.TRANSCRIBING -> heldStatusText.takeIf { it.isNotEmpty() }
                    else -> null.also { heldStatusText = "" }
                }

                AnimatedVisibility(
                    visible = displayText != null,
                    enter = fadeIn(tween(300)) + expandVertically(tween(300)),
                    exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                ) {
                    val text = displayText ?: return@AnimatedVisibility
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 6.dp)) {
                        Box(modifier = Modifier.size(16.dp), contentAlignment = Alignment.Center) {
                            if (isStreaming) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    color = if (text == thinkingStatus) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary,
                                    strokeWidth = 2.dp,
                                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                )
                            } else {
                                val icon = when (message.status) {
                                    MessageStatus.SUCCESS -> Icons.Default.CheckCircle
                                    MessageStatus.STOPPED -> Icons.Default.Stop
                                    else -> Icons.Default.Info
                                }
                                Icon(icon, null, modifier = Modifier.size(14.dp), tint = if (message.status == MessageStatus.SUCCESS) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error)
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text, style = ChatType.meta, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            var debouncedText by remember(isStreaming) { mutableStateOf(if (isStreaming) "" else message.text) }
            if (!isStreaming) {
                debouncedText = message.text
            } else {
                var lastUpdateMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
                var flushJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
                LaunchedEffect(message.text) {
                    if (message.text.isEmpty()) return@LaunchedEffect
                    val now = System.currentTimeMillis()
                    val elapsed = now - lastUpdateMs
                    if (elapsed >= STREAMING_MARKDOWN_FLUSH_MS) {
                        flushJob?.cancel()
                        debouncedText = message.text
                        lastUpdateMs = now
                    } else {
                        flushJob?.cancel()
                        flushJob = launch {
                            kotlinx.coroutines.delay(STREAMING_MARKDOWN_FLUSH_MS - elapsed)
                            debouncedText = message.text
                            lastUpdateMs = System.currentTimeMillis()
                        }
                    }
                }
            }

            // Level 1: anti-shrink for text and thinking content (kept after streaming ends)
            var streamingMaxHeightPx by remember { mutableIntStateOf(0) }
            var thinkingContentMaxHeightPx by remember { mutableIntStateOf(0) }

            // Reset anti-shrink heights when streaming restarts (e.g. regeneration)
            LaunchedEffect(isStreaming) {
                if (isStreaming) {
                    streamingMaxHeightPx = 0
                    thinkingContentMaxHeightPx = 0
                }
            }

            Column(
                // Anti-shrink lifted to the WHOLE content column (was only on the 576 text Box).
                // Logs showed the message height yo-yo'ing between its real height and a ~176px
                // skeleton (padding + status header + bottom Spacer) on every token while
                // streaming a <details> reply. The collapse wasn't in the text Box — it was in
                // the timeline/segments blocks (TimelineSegmentsContent's per-block enter
                // animation measures ~0 height before it finishes, and the text Box is empty
                // when useTimelineSegments=true). Pinning the whole column to its max-seen
                // height during streaming stops any sub-block's transient empty frame from
                // dropping the message down to the skeleton height.
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (isStreaming && streamingMaxHeightPx > 0)
                            Modifier.heightIn(min = with(LocalDensity.current) { streamingMaxHeightPx.toDp() })
                        else Modifier
                    )
                    .onSizeChanged { size ->
                        if (isStreaming) {
                            streamingMaxHeightPx = maxOf(streamingMaxHeightPx, size.height)
                        }
                    }
            ) {
                val isError = message.status == MessageStatus.ERROR || message.participant == Participant.ERROR

                // Only zero out thought height when legacy thought block is not shown
                if (message.segments != null || message.thoughts.isNullOrBlank()) {
                    setThoughtBlockHeight(0)
                }

                val segmentsOrNull = message.segments
                val mergedSegments = remember(segmentsOrNull) {
                    mergeAdjacentSegments(segmentsOrNull.orEmpty())
                }
                val normalizedToolCallDisplayMode = ToolCallDisplayModes.normalize(toolCallDisplayMode)
                val useTimelineSegments = normalizedToolCallDisplayMode != ToolCallDisplayModes.COMPACT &&
                    mergedSegments.any { it.type == "answer" }
                val groupAdjacentTimelineTools = normalizedToolCallDisplayMode == ToolCallDisplayModes.GROUPED_TIMELINE
                val timelineBlockKeys = remember(message.id, mergedSegments, groupAdjacentTimelineTools) {
                    buildTimelineBlockKeys(message.id, mergedSegments, groupAdjacentTimelineTools)
                }
                val timelineAppearanceSeenKeys = remember(message.id, normalizedToolCallDisplayMode) {
                    timelineBlockKeys.toMutableSet()
                }
                var timelineAppearanceInitialized by remember(message.id, normalizedToolCallDisplayMode) {
                    mutableStateOf(false)
                }
                val timelineAnimatedBlockKeys = if (isStreaming && timelineAppearanceInitialized) {
                    timelineBlockKeys.filterNotTo(linkedSetOf()) { it in timelineAppearanceSeenKeys }
                } else {
                    emptySet()
                }
                SideEffect {
                    timelineAppearanceSeenKeys.addAll(timelineBlockKeys)
                    if (!timelineAppearanceInitialized) {
                        timelineAppearanceInitialized = true
                    }
                }
                val detailSegments = remember(mergedSegments) {
                    mergedSegments.filter { it.type != "answer" }
                }

                AnimatedVisibility(
                    visible = useTimelineSegments,
                    // No container-level expand — each block animates its own alpha+scale
                    // appearance, so the section must not also unfold vertically from the top.
                    enter = fadeIn(tween(350, easing = LinearOutSlowInEasing)),
                    exit = fadeOut(tween(300))
                ) {
                    TimelineSegmentsContent(
                        segments = mergedSegments,
                        detailSegments = detailSegments,
                        message = message,
                        isStreaming = isStreaming,
                        groupAdjacentBlocks = groupAdjacentTimelineTools,
                        expandedStates = thoughtExpandedStates,
                        renderContext = renderContext,
                        animatedBlockKeys = timelineAnimatedBlockKeys,
                        onSegmentClick = { indices ->
                            onSegmentSelected(indices)
                        },
                        customReasoningPanelColor = customReasoningPanelColor,
                        reasoningPanelAlpha = reasoningPanelAlpha,
                        reasoningBackgroundImagePath = reasoningBackgroundImagePath,
                        customAssistantBubbleColor = customAssistantBubbleColor,
                        messageBubbleAlpha = messageBubbleAlpha,
                        splitBubbleByLine = splitBubbleByLine,
                    )
                }

                // Compact segment block: single block, newest title/icon when collapsed.
                // Answer segments are timeline anchors only; compact mode still renders
                // message.text below as the complete answer.
                AnimatedVisibility(
                    visible = !useTimelineSegments && detailSegments.isNotEmpty(),
                    // alpha + scale, fast-in slow-out — matches the timeline block appearance.
                    // Only plays when the block first appears live (visible false→true), not on history.
                    enter = fadeIn(tween(350, easing = LinearOutSlowInEasing)) +
                        scaleIn(initialScale = 0.9f, animationSpec = tween(350, easing = LinearOutSlowInEasing)),
                    exit = fadeOut(tween(500)) + shrinkVertically(tween(500))
                ) {
                    val segs = detailSegments
                    if (segs.isEmpty()) return@AnimatedVisibility
                    val lastSeg = segs.last()
                    val isLastTool = lastSeg.type == "tool"
                    val isToolInProgress = isLastTool && lastSeg.toolResult == null
                    val isThinking = message.status == MessageStatus.THINKING
                    val isToolCalling = message.status == MessageStatus.TOOL_CALLING
                    val isTranscribing = message.status == MessageStatus.TRANSCRIBING
                    val toolCount = segs.count { it.type == "tool" && it.toolResult != null }
                    val thoughtMs = thoughtDurationMs(segs) ?: message.thoughtTimeMs
                    val hasThought = thoughtMs != null && thoughtMs > 0
                    val hasVideoNarration = segs.any { it.type == "video_transcription" }
                    val hasImageTranscription = segs.any { it.type == "transcription" }
                    val collapsedTitle = when {
                        isThinking -> message.thoughtTitle ?: stringResource(R.string.thinking_ellipsis)
                        isTranscribing -> message.thoughtTitle ?: stringResource(R.string.transcription_ellipsis)
                        isToolCalling || isToolInProgress -> toolDisplayName(lastSeg.toolName)
                        else -> {
                            // Transcription/narration are pre-processing stages; surface them in the
                            // collapsed title even when the message also has thinking, otherwise a
                            // reasoning model (always-think) would bury the video narration under the
                            // "thought N seconds" label and the user can't tell a video was narrated.
                            when {
                                hasVideoNarration -> "Video Narration"
                                hasImageTranscription -> "Image Transcription"
                                hasThought -> thoughtDurationTitle(thoughtMs!!, toolCount)
                                toolCount > 0 -> stringResource(R.string.called_n_tools, toolCount)
                                message.thoughtTitle != null -> message.thoughtTitle
                                else -> stringResource(R.string.thinking_complete)
                            }
                        }
                    }
                    val mergedBottomPadding by animateDpAsState(
                        targetValue = if (isThoughtExpanded) 12.dp else 4.dp,
                        animationSpec = tween(500), label = "mergedPad"
                    )
                    val reasoningBaseColor = customReasoningPanelColor?.let { ColorMath.argbToColor(it) }
                        ?: MaterialTheme.colorScheme.surfaceColorAtElevation(2.dp)
                    Surface(
                        tonalElevation = 2.dp,
                        color = reasoningBaseColor,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = mergedBottomPadding + 6.dp)
                            .noOpBringIntoView()
                            .onSizeChanged { setThoughtBlockHeight(it.height) }
                    ) {
                        Box {
                            if (reasoningBackgroundImagePath.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = reasoningBackgroundImagePath,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.matchParentSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .matchParentSize()
                                        .background(reasoningBaseColor.copy(alpha = reasoningPanelAlpha))
                                )
                            }
                            Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { thoughtExpandedStates[message.id] = !isThoughtExpanded }
                                .padding(10.dp)
                        ) {
                            if (isToolCalling || isToolInProgress) {
                                Icon(Icons.Default.Build, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                            } else if (!isThinking && !hasThought && toolCount > 0) {
                                Icon(Icons.Default.Build, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                            } else if (isTranscribing || collapsedTitle == "Image Transcription") {
                                Icon(Icons.Filled.Image, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                            } else {
                                Icon(androidx.compose.ui.res.painterResource(id = com.orangeisland.app.R.drawable.thinking_orange), null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                collapsedTitle, style = ChatType.thoughtTitle,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                            )
                            Icon(
                                if (isThoughtExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                null, modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                        }
                        AnimatedVisibility(
                            visible = isThoughtExpanded,
                            enter = fadeIn(tween(400)) + expandVertically(tween(400)),
                            exit = fadeOut(tween(400)) + shrinkVertically(tween(400))
                        ) {
                            Column(
                                modifier = Modifier
                                    .then(
                                        if (thinkingContentMaxHeightPx > 0)
                                            Modifier.heightIn(min = with(LocalDensity.current) { thinkingContentMaxHeightPx.toDp() })
                                        else Modifier
                                    )
                                    .onSizeChanged { size ->
                                        if (isStreaming) {
                                            thinkingContentMaxHeightPx = maxOf(thinkingContentMaxHeightPx, size.height)
                                        }
                                    }
                            ) {
                                Spacer(modifier = Modifier.height(2.dp))
                                // Animate only items appended WHILE expanded during streaming.
                                val seenSegIdx = remember(message.id) { mutableSetOf<Int>() }
                                var seenSegInit by remember(message.id) { mutableStateOf(false) }
                                val newSegIdx = if (isStreaming && seenSegInit)
                                    segs.indices.filterNotTo(linkedSetOf()) { it in seenSegIdx } else emptySet()
                                SideEffect {
                                    segs.indices.forEach { seenSegIdx.add(it) }
                                    if (!seenSegInit) seenSegInit = true
                                }
                                segs.forEachIndexed { idx, seg ->
                                  AnimatedTimelineBlockAppearance(
                                    animationKey = "${message.id}:compactseg:$idx",
                                    animate = idx in newSegIdx
                                  ) {
                                   Column {
                                    if ((seg.type == "thought" && seg.content.isNotBlank()) || seg.type == "transcription") {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(18.dp))
                                                .clickable {
                                                    onSegmentSelected(listOf(idx))
                                                }
                                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                if (seg.type == "transcription") transcriptionLabel(segs, idx) else stringResource(R.string.tool_thinking),
                                                style = ChatType.meta,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            if (seg.content.isNotBlank()) {
                                                val flat = seg.content.replace('\n', ' ')
                                                val preview = if (isStreaming && idx == segs.lastIndex) {
                                                    if (flat.length > 60) "…${flat.takeLast(60)}" else flat
                                                } else flat
                                                Text(
                                                    text = preview,
                                                    style = ChatType.metaNormal,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            } else {
                                                Text(
                                                    text = "Image transcription is empty.",
                                                    style = ChatType.metaNormal,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                                )
                                            }
                                        }
                                    } else if (seg.type == "tool") {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(18.dp))
                                                .clickable {
                                                    onSegmentSelected(listOf(idx))
                                                }
                                                .padding(horizontal = 10.dp, vertical = 8.dp)
                                        ) {
                                            Text(
                                                toolDisplayName(seg.toolName),
                                                style = ChatType.meta,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = toolSummary(seg),
                                                style = ChatType.metaNormal,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                            )
                                            seg.audioPath?.let { path ->
                                                AudioMessageBar(path = path, modifier = Modifier.padding(top = 6.dp))
                                            }
                                            seg.imagePath?.let { path ->
                                                coil.compose.AsyncImage(
                                                    model = path,
                                                    contentDescription = null,
                                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                                    modifier = Modifier
                                                        .padding(top = 6.dp)
                                                        .fillMaxWidth()
                                                        .aspectRatio(1f)
                                                        .clip(RoundedCornerShape(12.dp))
                                                )
                                            }
                                        }
                                    }
                                    if (idx < segs.lastIndex) {
                                        HorizontalDivider(
                                            modifier = Modifier.padding(vertical = 2.dp),
                                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
                                        )
                                    }
                                   }
                                  }
                                }
                            }
                        }
                        }
                        }
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        // Anti-shrink moved up to the content Column (283); this Box no longer
                        // pins its own height or tracks streamingMaxHeightPx, to avoid a double
                        // constraint where the inner Box's min would be set from the whole-column
                        // measurement.
                        .noOpBringIntoView()
                ) {
                    if (isError) {
                        Surface(color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f), contentColor = MaterialTheme.colorScheme.onErrorContainer, shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.Info, null, modifier = Modifier.size(16.dp).padding(top = 2.dp), tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(12.dp))
                                SelectionContainer {
                                    Text(
                                        debouncedText.ifEmpty { stringResource(R.string.failed_to_generate) },
                                        style = ChatType.errorBody,
                                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    } else if (debouncedText.isNotEmpty() && !useTimelineSegments) {
                        // Split a finished (non-streaming) reply across stacked bubbles at the
                        // model's own \n boundaries. Streaming is excluded: the last line is still
                        // being written, so forcibly cutting it on every token arrival would make
                        // the bubble count thrash. Only "settle" into multiple bubbles once done.
                        if (!isStreaming && splitBubbleByLine) {
                            val bubbleSegments = remember(debouncedText) {
                                debouncedText.splitIntoBubbleSegments()
                            }
                            Column(
                                horizontalAlignment = Alignment.Start,
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                bubbleSegments.forEachIndexed { segIndex, segment ->
                                    key(segIndex) {
                                        // Per-segment bubble. Applies the same bubble-transparency
                                        // slider as the single-bubble shell, so split bubbles stay
                                        // visually consistent with the unsplit view.
                                        val segmentColor = customAssistantBubbleColor
                                            ?.let { ColorMath.argbToColor(it).let { c -> c.copy(alpha = c.alpha * messageBubbleAlpha) } }
                                            ?: MaterialTheme.colorScheme.surfaceContainerHigh
                                        // A segment carrying a markdown image (or any block-level
                                        // construct the lightweight inline renderer can't handle) falls
                                        // back to the full markdown renderer so the image/block actually
                                        // renders; plain one-liners keep the cheap AnnotatedString path
                                        // that wraps to content width.
                                        val needsFullMarkdown = com.orangeisland.app.util.needsFullMarkdownRenderer(segment)
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(20.dp))
                                                .background(segmentColor)
                                                .padding(12.dp)
                                        ) {
                                            SelectionContainer {
                                                if (needsFullMarkdown) {
                                                    MarkdownTextContent(
                                                        text = segment,
                                                        renderContext = renderContext,
                                                        modifier = Modifier.widthIn(max = 240.dp)
                                                    )
                                                } else {
                                                    Text(
                                                        text = com.orangeisland.app.util.buildInlineMarkdownAnnotatedString(
                                                            text = segment,
                                                            codeBackground = MaterialTheme.colorScheme.surfaceVariant,
                                                            codeColor = MaterialTheme.colorScheme.onSurfaceVariant
                                                        ),
                                                        style = ChatType.body,
                                                        color = MaterialTheme.colorScheme.onSurface,
                                                        modifier = Modifier.widthIn(max = 240.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            var keepBlockRenderer by remember(message.id) { mutableStateOf(false) }
                            val useBlockRenderer = isStreaming || keepBlockRenderer
                            val streamingBlocks = rememberStreamingMarkdownBlocks(
                                content = debouncedText,
                                flavour = markdownFlavour,
                                active = useBlockRenderer
                            )

                            LaunchedEffect(isStreaming) {
                                if (isStreaming) {
                                    keepBlockRenderer = true
                                } else if (keepBlockRenderer) {
                                    // Streaming just ended. Previously keepBlockRenderer stayed true forever
                                    // once set, permanently pinning this message to the custom incremental
                                    // block-splitting renderer — which has been shown (via
                                    // MarkdownTableParsingTest) to diverge from the underlying library's own
                                    // one-shot parse for multi-line constructs like GFM tables. A short delay
                                    // lets the just-finished stream visually settle before handing off to the
                                    // fully-parsed, non-streaming renderer (MarkdownTextContent), which IS the
                                    // path proven correct by the unit test. This preserves the original intent
                                    // of avoiding a jarring flicker right at generation end, while ensuring
                                    // every message eventually renders through the correct path instead of
                                    // being stuck on the streaming one forever.
                                    kotlinx.coroutines.delay(300)
                                    keepBlockRenderer = false
                                }
                            }

                            Box {
                                SelectionContainer {
                                    Box(modifier = Modifier.fillMaxWidth()) {
                                        if (useBlockRenderer) {
                                            StreamingMarkdownBlockContent(
                                                blocks = streamingBlocks,
                                                renderContext = renderContext,
                                                modifier = Modifier
                                                    .fillMaxWidth(),
                                                tailIsStreaming = isStreaming
                                            )
                                        }
                                        if (!useBlockRenderer && !isStreaming) {
                                            key("full-markdown") {
                                                RecomposeSafeMarkdown(
                                                    content = debouncedText,
                                                    isStreaming = false,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                ) { text ->
                                                    MarkdownTextContent(
                                                        text = text,
                                                        renderContext = renderContext
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                if (isStreaming) {
                                    Box(
                                        modifier = Modifier
                                            .matchParentSize()
                                            .pointerInput(Unit) {
                                                detectTapGestures(onLongPress = { })
                                            }
                                    )
                                }
                            }
                        }
                    }
                }
                // Paths already claimed by a tool-call segment (speak / generate_image) render
                // inline in the timeline card at their actual position; only render here the
                // paths that AREN'T claimed by any segment — that's the legacy path for messages
                // generated before segments carried audioPath/imagePath.
                val claimedImagePaths = remember(message.segments) {
                    message.segments?.mapNotNull { it.imagePath }?.toSet() ?: emptySet()
                }
                val claimedAudioPaths = remember(message.segments) {
                    message.segments?.mapNotNull { it.audioPath }?.toSet() ?: emptySet()
                }
                val unclaimedImages = message.images.filter { it !in claimedImagePaths }
                val unclaimedAudio = message.audio.filter { it !in claimedAudioPaths }
                if (message.participant == Participant.MODEL && unclaimedImages.isNotEmpty()) {
                    // Generated images are primary output, not input references:
                    // render as a full-width square card, image cropped to fill
                    // with rounded corners, tap to view fullscreen.
                    Column(
                        modifier = Modifier.padding(top = if (debouncedText.isNotEmpty()) 8.dp else 0.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        unclaimedImages.forEachIndexed { idx, path ->
                            coil.compose.AsyncImage(
                                model = path,
                                contentDescription = null,
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .combinedClickable(
                                        onClick = { onMediaClick(unclaimedImages, idx) },
                                        onLongClick = { haptics.longPress() }
                                    )
                            )
                        }
                    }
                }
                if (message.participant == Participant.MODEL && unclaimedAudio.isNotEmpty()) {
                    Column(
                        modifier = Modifier.padding(top = if (debouncedText.isNotEmpty() || unclaimedImages.isNotEmpty()) 8.dp else 0.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        unclaimedAudio.forEach { path ->
                            AudioMessageBar(path = path)
                        }
                    }
                }
                if (!isStreaming && message.status == MessageStatus.STOPPED) {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), shape = RoundedCornerShape(8.dp), modifier = Modifier.padding(top = if (debouncedText.isNotEmpty()) 8.dp else 0.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            Icon(Icons.Default.Info, null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.generation_stopped), style = ChatType.meta, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        }
                    }
                }

                if (message.participant == Participant.MODEL) {
                    if (showUsageStats && message.tokenCount > 0) {
                        AnimatedVisibility(
                            visible = !isStreaming,
                            enter = fadeIn(tween(400)),
                            exit = fadeOut(tween(200))
                        ) {
                            val cacheRatio = if (message.tokenCount > 0) (message.cachedTokenCount * 100 / message.tokenCount) else 0
                            val text = buildString {
                                append("${message.tokenCount} tokens")
                                if (message.cachedTokenCount > 0) append(" · ${stringResource(R.string.cache_hit)} ${message.cachedTokenCount} ($cacheRatio%)")
                                if (message.contextMessageCount > 0) append(" · ${stringResource(R.string.context_messages, message.contextMessageCount)}")
                                message.generationDurationMs?.let { ms ->
                                    append(" · 用时 ${"%.1f".format(ms / 1000.0)}s")
                                }
                            }
                            Text(
                                text = text,
                                style = ChatType.micro,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                    AnimatedVisibility(
                        visible = !isStreaming,
                        enter = fadeIn(tween(400)) + expandVertically(tween(400)),
                        exit = fadeOut(tween(200)) + shrinkVertically(tween(200))
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { clipboardManager.setText(AnnotatedString(message.text)); haptics.success() }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.ContentCopy, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            }
                            IconButton(onClick = { onRegenerate(message.id) }, enabled = !isLoading, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Refresh, null, modifier = Modifier.size(19.dp), tint = if (isLoading) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                            }
                            Box {
                                IconButton(onClick = { showMenu = true }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.MoreVert, null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                                }
                                DropdownMenu(
                                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                                    tonalElevation = 16.dp,
                                    shape = RoundedCornerShape(12.dp),
                                    expanded = showMenu,
                                    onDismissRequest = { showMenu = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.edit)) },
                                        onClick = { showMenu = false; onStartEdit() },
                                        enabled = isEditingAllowed,
                                        leadingIcon = { Icon(Icons.Default.Edit, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.info)) },
                                        onClick = { showMenu = false; onShowInfo() },
                                        leadingIcon = { Icon(Icons.Default.Info, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(stringResource(R.string.delete), color = if (!isLoading) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.error.copy(alpha = 0.5f)) },
                                        onClick = { showMenu = false; onShowDelete() },
                                        enabled = !isLoading,
                                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = if (!isLoading) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.error.copy(alpha = 0.5f)) }
                                    )
                                }
                            }

                            if (totalBranches > 1) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .padding(start = 8.dp)
                                        .clip(RoundedCornerShape(100))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                        .padding(horizontal = 4.dp)
                                ) {
                                    IconButton(onClick = { onSwitchBranch(-1) }, enabled = branchIndex > 0 && isEditingAllowed, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null, modifier = Modifier.size(16.dp))
                                    }
                                    Text("${branchIndex + 1} / $totalBranches", style = MaterialTheme.typography.labelSmall)
                                    IconButton(onClick = { onSwitchBranch(1) }, enabled = branchIndex < totalBranches - 1 && isEditingAllowed, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // Orange Island sprout decoration on the assistant bubble's bottom-end
        // corner (UI Playground v0.4). Drawn after the content so it sits on
        // top, but DecorativeCorner adds no click handler, so it never
        // intercepts taps meant for the bubble. Only when the outer single
        // bubble silhouette is active, so split-bubble replies stay clean.
        if (useSingleOuterBubble) {
            DecorativeCorner(
                res = R.drawable.island_deco_sprout,
                width = 72.dp,
                alignment = Alignment.BottomEnd,
                offsetX = (-8).dp,
                offsetY = (-6).dp,
                alpha = 0.9f,
            )
        }
    }
}

/**
 * Inline editor shown in place of the whole assistant bubble content when [isEditing].
 * Edits only the flat text; [MessageGenerationController.editAssistantMessage] handles
 * folding it back into segments (if any) and creating the new branch on save.
 */
@Composable
private fun AssistantEditModeContent(
    initialText: String,
    onSave: (String) -> Unit,
    onCancel: () -> Unit,
) {
    val editState = rememberTextFieldState(initialText)
    val editScrollState = rememberScrollState()
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Box(modifier = Modifier.noOpBringIntoView()) {
            TextField(
                state = editState,
                scrollState = editScrollState,
                modifier = Modifier.fillMaxWidth(),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                )
            )
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onCancel) { Text(stringResource(R.string.cancel)) }
            TextButton(onClick = { onSave(editState.text.toString()) }) { Text(stringResource(R.string.save)) }
        }
    }
}
